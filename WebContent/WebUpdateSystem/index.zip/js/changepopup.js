	function OpenPopUp(pid)
	{

					//{
						//show box
						$(document).ready(function() {
							$('.fancybox').fancybox();
						});

	}
	function checkfields()
	{
		isvalid=true;
		var ptitle = $.trim($('#other_policy_title').val());
		var pfile = $.trim($('#other_policy_file').val());
		if(ptitle == "")
			{
			alert("Please enter value for Policy Title");
			isvalid=false;
			}
		if(pfile == "")
		{
			alert("Please select Policy file");
			isvalid=false;
		}
		
		if(!pfile.match(/pdf$/i))
		{
			alert("Only PDF files can be uploaded");
			isvalid=false;
		}
			
		
		return isvalid;
		
		
		
	}
    function closewindow()
    {
    	//blank fields
    	$.fancybox.close(); 
    }
    function ajaxRequestInfo(pid,eid)
    {
    	var isvalid=false;
    	$.ajax(
     			{
     				type: "POST",  
     				url: "getNLESDEmployeePayAdviceInfo.html",
     				data: {
     					empid: eid,payid:pid
     				}, 
     				success: function(xml){
     					$(xml).find('EMPLOYEE').each(function(){
     						if($(this).find("MESSAGE").text() == "NO ERROR")
     								{
     									var empname = $(this).find("EMPNAME").text();
    	                   				$("#empname").text(empname);
                        				var empemail = $(this).find("EMAIL").text();
    	                   				$("#empemail").text(empemail);
                        				var payperiod = $(this).find("PPERIOD").text();
    	                   				$("#payperiod").text(payperiod);
                        				$("#hidEID").val(eid);
                        				$("#hidPID").val(pid);    	                   				
										isvalid=true;
    	                   				
     								}else{
     									alert($(this).find("ERROR").text());
     									isvalid=false;
     								}

     					});     					
     				},
     				  error: function(xhr, textStatus, error){
     				      alert(xhr.statusText);
     				      alert(textStatus);
     				      alert(error);
     				  },
     				dataType: "text",
     				async: false
     			}
     		);
    	return isvalid;
}
    function sendinfo()
    {
    	
    	var test=checkfields();
    	
    	if(ajaxSendInfo())
    	{
    		$.fancybox.close();
    	}
    }
    function ajaxSendInfo()
    {
    	var isvalid=false;
		var ptitle = $.trim($('#other_policy_title').val());
		var pfile = $('#other_policy_file');
		var pid = $.trim($('#id').val());
		//var ufile= pfile.files[0];
		//var ufile = $('#other_policy_title').prop('files');
		var ufile = $('#other_policy_file')[0].files[0];
		//poltitle: ptitle,polid:pid,polfile: ufile 
		var requestd = new FormData();
		requestd.append('polid',pid);
		requestd.append('poltitle',ptitle);
		requestd.append('polfile',ufile);
		//mimeType:"multipart/form-data",
		
        $.ajax({
            url: "addOtherPolicyFile.html",
            type: 'POST',
            data:  requestd,
            contentType: false,
            cache: false,
            processData:false,
            success: function(xml)
            {
            	
					var i=1;
					cleartable();
 					$(xml).find('FILES').each(function(){
 							
 							if($(this).find("MESSAGE").text() == "SUCCESS")
 								{
 									
									var newrow="";
									if(i % 2 == 0)
									{
									newrow ="<tr style='background-color:#E5F2FF;' id='" + $(this).find("ID").text() + "'>";
 									}else{
 										newrow ="<tr style='background-color:#white;' id='" + $(this).find("ID").text() + "'>";
 									}
 									//alert("found");
									//now we add each one to the table
									newrow += "<td>" + $(this).find("PFTITLE").text() + "</td>";
									newrow += "<td>" + $(this).find("PFDOC").text() + "</td>";
									newrow += "<td>" + $(this).find("ADDEDBY").text() + "</td>";
									newrow += "<td>" + $(this).find("DATEADDED").text() + "</td>";
									newrow += "<td><a class='fancybox' href='#inline1' title='Confirm Deletion' onclick='OpenPopUp(" + $(this).find("ID").text() + ");'>Delete</a></td>";
									//<td class='list' align='center'><a class="fancybox" href="#inline1" title="Confirm Deletion" onclick="OpenPopUp(${pledge.pk});">Delete</a></td>
									newrow +="</tr>";
									$('table#showlists tr:last').after(newrow);
									i=i+1;
									isvalid=true;
	                   				
 								}else{
 									alert($(this).find("MESSAGE").text()+ "1");
 									
 								}
						});
            },
            error: function(jqXHR, textStatus, errorThrown) 
            {
            		alert("error");
            },
				dataType: "text",
 				async: false
       });

    	return isvalid;
    }
    function cleartable()
    {
    	$('#showlists td').parent().remove();
    }
   